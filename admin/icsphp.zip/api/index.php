<?php
require '../autoload.php';

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;

$app = AppFactory::create();

// Database connection
$container = $app->getContainer();
$container['db'] = function () {
    $host = 'localhost';
    $db = 'icsphp';
    $user = 'root';
    $pass = 'admin@123';
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        return new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }
};

// GET route to retrieve users based on firstName and age
$app->get('/api/orders', function (Request $request, Response $response, $args) {
    $params = $request->getQueryParams();
    $admission_no = $params['admission_no'] ?? null;
    $class_id = $params['class_id'] ?? null;

    if (!$admission_no || !$class_id) {
        $response->getBody()->write(json_encode(['error' => 'Invalid parameters']));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $db = $this->get('db');
    $stmt = $db->prepare('SELECT * FROM orders WHERE admission_no = :admission_no AND class_id = :class_id');
    $stmt->execute(['admission_no' => $admission_no, 'class_id' => $class_id]);
    $users = $stmt->fetchAll();

    if (!$users) {
        $response->getBody()->write(json_encode(['message' => 'No users found']));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
    }

    $response->getBody()->write(json_encode($users));
    return $response->withHeader('Content-Type', 'application/json');
});

$app->run();
