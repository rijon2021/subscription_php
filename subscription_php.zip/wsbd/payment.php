
<?php include_once('common/header.php') ?>
<<<<<<< HEAD
      

<?php
=======
>>>>>>> d41c53a44fd647511be91aa168b03788bb4355c0

    if(isset($_POST['save'])){
        
        $studentName = $_POST['student_name'];
        $mobile = $_POST['mobile'];
        $SSCRoll = $_POST['ssc_roll'];
        $studentClass = $_POST['studentClass'];
        $sslTxn = 'Txn255225';
        // $timestamp = date("Y-m-d H:i:s");

        $sql = "INSERT INTO students (studentName, mobile, SSCRoll, studentClass, sslTxn, createDate)
    VALUES ('$studentName', '$mobile', '$SSCRoll', '$studentClass', '$sslTxn', CURRENT_TIMESTAMP())";
  

        if ($mySqlCon->query($sql)) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $mySqlCon->error;
        }$mySqlCon->close();
    // if ($mySqlCon->mysqli_query($sql) === TRUE) {
    //    echo "New record created successfully";
    //  } else {
    //    echo "Error: " . $sql . "<br>" . $conn->error;
    //  }
   
    
    }
    
   
?>
        <!-- Page Banner Start -->
        <div class="section page-banner-section" style="background-image: url(assets/images/bg/page-banner.jpg);">
            <div class="container">
                <div class="page-banner-wrap">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- Page Banner Content Start -->
                            <div class="page-banner text-center">
                                <h2 class="title">Subscription</h2>
                                <ul class="breadcrumb justify-content-center">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Subscription</li>
                                </ul>
                            </div>
                            <!-- Page Banner Content End -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page Banner End -->
        <!-- Pricing Start -->
        <div class="section techwix-pricing-section section-padding">
            <div class="container">
                <!-- Pricing Wrap Start -->
                <div class="pricing-wrap">
                    <div class="section-title text-center">
                        <h3 class="sub-title">Carefully fill up your information before make the payment</h3>
                        <h2 class="title"> Student Payment Information</h2>
                    </div>
                    <hr>
                    <form action="payment.php" method="post" >
                    <div class="pricing-content-wrap">
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="row">
                                            <label for="" class="col-md-4 control-label text-end mt-2">Class</label>
                                            <div class="col-md-8">
                                                <select name="studentClass" class="form-control" id="">
                                                    <option value="">Select Class</option>
                                                    <option value="Eleven">Eleven</option>
                                                    <option value="Twelve">Twelve</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row">
                                            <label for="" class="col-md-4 control-label mt-2 text-end">Student Name</label>
                                            <div class="col-md-8">
                                            <input type="text" class="form-control" name="student_name">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row mt-2">
                                            <label for="" class="col-md-4 control-label mt-2 text-end">Mobile</label>
                                            <div class="col-md-8">
                                            <input type="text" class="form-control" name="mobile">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="row mt-2">
                                            <label for="" class="col-md-4 control-label mt-2 text-end">SSC Roll</label>
                                            <div class="col-md-8">
                                            <input type="text" class="form-control" name="ssc_roll">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6"></div>
                                    <div class="col-md-6">
                                        <table class="table table-bordered mt-3">
                                            <tr>
                                                <td class="info-td">Name</td>
                                                <td class="text-center" style="width:10px">:</td>
                                                <td>Kamrul Hasan Rijon</td>
                                            </tr>
                                            <tr>
                                                <td class="info-td">Class</td>
                                                <td class="text-center" style="width:10px">:</td>
                                                <td>Eleven</td>
                                            </tr>
                                            <tr>
                                                <td class="info-td">Mobile</td>
                                                <td class="text-center" style="width:10px">:</td>
                                                <td>01700011254</td>
                                            </tr>
                                            <tr>
                                                <td class="info-td">SSC Roll</td>
                                                <td class="text-center" style="width:10px">:</td>
                                                <td>124589</td>
                                            </tr>
                                            <tr>
                                                <td class="info-td">Amount</td>
                                                <td class="text-center" style="width:10px">:</td>
                                                <input type="hidden" name="amount">
                                                <td><h3 value="10">300</h4>TK</td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="text-end">
                                            <button type="submit" class="ssl-btn" name="save">
                                                Payment By <img src="./assets/images/ssl-icon.png"></button>
                                           
                                        </div>
                                    </div>
                                    
                                </div>
                                
                            </div>
                            
                        </div>
                    </div>
                    </form>
                </div>
                <!-- Pricing Wrap End -->
            </div>
        </div>
        <!-- Pricing End -->


    <?php include_once('common/footer.php') ?>