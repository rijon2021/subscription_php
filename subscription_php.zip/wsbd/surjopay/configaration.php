<?php

	define('SP_USERNAME','sp_sandbox');
	define('SP_PASSWORD','pyyk97hu&6u6');
	define('PREFIX','NOK');
	define('SHURJOPAY_API','https://sandbox.shurjopayment.com/');
	define('SP_CALLBACK','http://wsbd.oo/surjopay/return.php');
	define('LOG_LOCATION','shujoPay-plugin-log/');
?>