
<?php include_once('common/header.php') ?>

        <!-- Page Banner Start -->
        <div class="section page-banner-section" style="background-image: url(assets/images/bg/page-banner.jpg);">
            <div class="container">
                <div class="page-banner-wrap">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- Page Banner Content Start -->
                            <div class="page-banner text-center">
                                <h2 class="title">Refund Policy</h2>
                                <ul class="breadcrumb justify-content-center">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Refund Policy</li>
                                </ul>
                            </div>
                            <!-- Page Banner Content End -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page Banner End -->
        <!-- Pricing Start -->
        <div class="section techwix-pricing-section section-padding">
            <div class="container">
                <!-- Pricing Wrap Start -->
                <div class="row">
                <div class="col-md-12">
                    <h3>Refund Policy</h4>
                    <p>Contact our call center any payment issue. Thank you</p>
                    <p>Mobile : 01551807097</p>
                </div>
                </div>
                <!-- Pricing Wrap End -->
            </div>
        </div>
        <!-- Pricing End -->


    <?php include_once('common/footer.php') ?>