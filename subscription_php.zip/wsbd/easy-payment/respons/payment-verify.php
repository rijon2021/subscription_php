
<?php include_once('common/header.php') ?>
        <!-- Page Banner Start -->
        <div class="section page-banner-section" style="background-image: url(assets/images/bg/page-banner.jpg);">
            <div class="container">
                <div class="page-banner-wrap">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- Page Banner Content Start -->
                            <div class="page-banner text-center">
                                <h2 class="title">Payment Verify</h2>
                                <ul class="breadcrumb justify-content-center">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Payment Verify</li>
                                </ul>
                            </div>
                            <!-- Page Banner Content End -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page Banner End -->
        <!-- Pricing Start -->
        <div class="section techwix-pricing-section section-padding">
            <div class="container">
                <!-- Pricing Wrap Start -->
                <div class="pricing-wrap">
                    <div class="section-title text-center">
                        <h2 class="title">  Payment Verify</h2>
                    </div>
                    <hr>
                    <div class="pricing-content-wrap">
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <div class="row">
                                    
                                    
                                    <div class="col-md-8">
                                        <div class="row">
                                            <label for="" class="col-md-4 control-label mt-2 text-end">Transaction ID</label>
                                            <div class="col-md-8">
                                            <input type="text" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <a class="btn-sm btn-primary mt-1" href="">Verify Payment</a>
                                    </div>
                                    
                                    <div class="col-md-12 mt-3">
                                        <table class="table table-bordered mt-3">
                                            <tr>
                                                <td class="info-td">Name</td>
                                                <td class="text-center" style="width:10px">:</td>
                                                <td>Kamrul Hasan Rijon</td>
                                            </tr>
                                            <tr>
                                                <td class="info-td">Class</td>
                                                <td class="text-center" style="width:10px">:</td>
                                                <td>Eleven</td>
                                            </tr>
                                            <tr>
                                                <td class="info-td">Mobile</td>
                                                <td class="text-center" style="width:10px">:</td>
                                                <td>01700011254</td>
                                            </tr>
                                            <tr>
                                                <td class="info-td">SSC Roll</td>
                                                <td class="text-center" style="width:10px">:</td>
                                                <td>124589</td>
                                            </tr>
                                            <tr>
                                                <td class="info-td">Transation ID</td>
                                                <td class="text-center" style="width:10px">:</td>
                                                <td><h6 class="text-primary">WTXN124585452</h6></td>
                                            </tr>
                                            <tr>
                                                <td class="info-td">Payment Status</td>
                                                <td class="text-center" style="width:10px">:</td>
                                                <td><h3 class="text-primary">Paid</h3></td>
                                            </tr>
                                            <tr>
                                                <td class="info-td">Amount</td>
                                                <td class="text-center" style="width:10px">:</td>
                                                <td><h3>300</h4>TK</td>
                                            </tr>
                                        </table>
                                    </div>
                                    
                                    
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <!-- Pricing Wrap End -->
            </div>
        </div>
        <!-- Pricing End -->


    <?php include_once('common/footer.php') ?>