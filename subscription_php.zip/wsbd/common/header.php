
<?php
include("dbconnection.php"); 
 ?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Web Support BD - IT Solutions Consultancy Firm </title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php $baseUrl; ?>/assets/images/favicon.png">
    <!-- CSS
	============================================ -->
    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="<?php $baseUrl; ?>/assets/css/plugins/all.min.css">
    <link rel="stylesheet" href="<?php $baseUrl; ?>/assets/css/plugins/flaticon.css">
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="<?php $baseUrl; ?>/assets/css/plugins/bootstrap.min.css">
    <link rel="stylesheet" href="<?php $baseUrl; ?>/assets/css/plugins/swiper-bundle.min.css">
    <link rel="stylesheet" href="<?php $baseUrl; ?>/assets/css/plugins/aos.css">
    <link rel="stylesheet" href="<?php $baseUrl; ?>/assets/css/plugins/magnific-popup.css">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php $baseUrl; ?>/assets/css/style.css">

</head>

<body>

    <div class="main-wrapper">
        <!-- Preloader start -->
        <div id="preloader">
            <div class="preloader">
                <span></span>
                <span></span>
            </div>
        </div>
        <!-- Preloader End -->

        <!-- Header Start  -->
        <div id="header" class="section header-section header-section-04">

            <div class="container">

                <!-- Header Wrap Start  -->
                <div class="header-wrap">

                    <div class="header-logo">
                        <a class="logo-black" href="index.php"><img src="<?php $baseUrl; ?>/assets/images/logo.png" alt=""></a>
                        <a class="logo-white" href="index.php"><img src="<?php $baseUrl; ?>/assets/images/logo-3.png" alt=""></a>
                    </div>

                    <div class="header-menu d-none d-lg-block">
                        <ul class="main-menu">
                            <li class="active-menu">
                                <a href="index.php">Home</a></li>
                            <li>
                                <a href="about.php">About Us</a>
                            </li>
                            <li>
                                <a href="payment/example_easycheckout.php">Payment</a>
                            </li>
                            <li>
                                <a href="payment-verify.php">Payment Verify</a>
                            </li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </div>

                    <!-- Header Meta Start -->
                    <div class="header-meta">
                        <!-- Header Search Start -->
                        <div class="header-search">
                            <a class="search-btn" href="#"><i class="flaticon-loupe"></i></a>
                            <div class="search-wrap">
                                <div class="search-inner">
                                    <i id="search-close" class="flaticon-close search-close"></i>
                                    <div class="search-cell">
                                        <form action="#">
                                            <div class="search-field-holder">
                                                <input class="main-search-input" type="search" placeholder="Search Your Keyword...">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Header Search End -->

                        <div class="header-btn d-none d-xl-block">
                            <a class="btn px-3" href="login-register.php"><i class="fa fa-phone"></i> 01551807097</a>
                        </div>
                        <!-- Header Toggle Start -->
                        <div class="header-toggle d-lg-none">
                            <button data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>
                        <!-- Header Toggle End -->
                    </div>
                    <!-- Header Meta End  -->

                </div>
                <!-- Header Wrap End  -->

            </div>
        </div>
        <!-- Header End -->
        <!-- Offcanvas Start-->
        <div class="offcanvas offcanvas-start" id="offcanvasExample">
                    <div class="offcanvas-header">
                        <!-- Offcanvas Logo Start -->
                        <div class="offcanvas-logo">
                            <a href="index.php"><img src="assets/images/logo-white.png" alt=""></a>
                        </div>
                        <!-- Offcanvas Logo End -->
                        <button type="button" class="close-btn" data-bs-dismiss="offcanvas"><i class="flaticon-close"></i></button>
                    </div>

                    <!-- Offcanvas Body Start -->
                    <div class="offcanvas-body">
                        <div class="offcanvas-menu">
                            <ul class="main-menu">
                                <li class="active-menu">
                                    <a href="index.php">Home</a>
                                </li>
                                <li>
                                    <a href="about.php">Aboute Us</a>
                                </li>
                                <li><a href="service.php">Service</a></li>
                                <li><a href="contact.php">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Offcanvas Body End -->
                </div>
                <!-- Offcanvas End -->