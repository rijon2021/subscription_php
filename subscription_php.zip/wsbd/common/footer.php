

        <!-- Footer Section Start -->
        <div class="section footer-section footer-section-04" style="background-image: url(<?php $baseUrl; ?>/assets/images/bg/footer-bg3.jpg);">

            <div class="container">
                <!-- Footer Widget Wrap Start -->
                <div class="footer-widget-wrap">
                    <div class="row">
                        <div class="col-lg-3 col-sm-6">
                            <!-- Footer Widget Start -->
                            <div class="footer-widget-about">
                                <a class="footer-logo" href="index.html"><img src="<?php $baseUrl; ?>/assets/images/logo.png" alt="Logo"></a>
                                <p>Accelerate innovation with world-class tech teams We’ll match you to an entire remote team of incredible freelance talent.</p>
                                <div class="footer-social">
                                    <ul class="social">
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Footer Widget End -->
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <!-- Footer Widget Start -->
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Useful Links</h4>

                                <div class="widget-link">
                                    <ul class="link">
                                        <li><a href="terms-condition.php">Terms & Conditions</a></li>
                                        <li><a href="about-us.php">About Company</a></li>
                                        <li><a href="payment.php">Payment Gatway</a></li>
                                        <li><a href="refund.php">Refund Policy</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Footer Widget End -->
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <!-- Footer Widget Start -->
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Our Services</h4>

                                <div class="widget-link">
                                    <ul class="link">
                                        <li><a href="#">Data Security</a></li>
                                        <li><a href="#">IT Managment</a></li>
                                        <li><a href="#">Outsourcing</a></li>
                                        <li><a href="#">Networking</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Footer Widget End -->
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <!-- Footer Widget Start -->
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Contact Information</h4>

                                <div class="widget-info">
                                    <ul>
                                        <li>
                                            <div class="info-icon">
                                                <i class="flaticon-phone-call"></i>
                                            </div>
                                            <div class="info-text">
                                                <span><a href="#">+8801551807097</a></span>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="info-icon">
                                                <i class="far fa-envelope-open"></i>
                                            </div>
                                            <div class="info-text">
                                                <span><a href="#">info@websupportbd.com</a></span>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="info-icon">
                                                <i class="flaticon-pin"></i>
                                            </div>
                                            <div class="info-text">
                                                <strong>Head Office :</strong>
                                                <span>25/3, Join Quater, Mohammadpur, Dhaka - 1207</span>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="info-icon">
                                                <i class="flaticon-pin"></i>
                                            </div>
                                            <div class="info-text">
                                            <strong>Jamalpur Branch:</strong>
                                                <span>Sordar Para , Jamalpur</span>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Footer Widget End -->
                        </div>
                    </div>
                </div>
                <!-- Footer Widget Wrap End -->
            </div>

            <!-- Footer Copyright Start -->
            <div class="footer-copyright-area">
                <div class="container">
                    <div class="footer-copyright-wrap">
                        <div class="row align-items-center">
                            <div class="col-lg-12">
                                <!-- Footer Copyright Text Start -->
                                <div class="copyright-text text-center">
                                    <p>© Copyrights 2022 Web Support BD All rights reserved. </p>
                                </div>
                                <!-- Footer Copyright Text End -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Copyright End -->
        </div>
        <!-- Footer Section End -->

        <!-- back to top start -->
        <div class="progress-wrap">
            <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
                <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
            </svg>
        </div>
        <!-- back to top end -->

    </div>

    <!-- JS
    ============================================ -->
    <script src="<?php $baseUrl; ?>/assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="<?php $baseUrl; ?>/assets/js/vendor/modernizr-3.11.2.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="<?php $baseUrl; ?>/assets/js/plugins/popper.min.js"></script>
    <script src="<?php $baseUrl; ?>/assets/js/plugins/bootstrap.min.js"></script>

    <!-- Plugins JS -->
    <script src="<?php $baseUrl; ?>/assets/js/plugins/swiper-bundle.min.js"></script>
    <script src="<?php $baseUrl; ?>/assets/js/plugins/aos.js"></script>
    <script src="<?php $baseUrl; ?>/assets/js/plugins/waypoints.min.js"></script>
    <script src="<?php $baseUrl; ?>/assets/js/plugins/back-to-top.js"></script>
    <script src="<?php $baseUrl; ?>/assets/js/plugins/jquery.counterup.min.js"></script>
    <script src="<?php $baseUrl; ?>/assets/js/plugins/appear.min.js"></script>
    <script src="<?php $baseUrl; ?>/assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->


    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

</body>


<!-- Mirrored from thepixelcurve.com/html/techwix/techwix/index-4.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 10 Feb 2024 05:27:42 GMT -->
</html>