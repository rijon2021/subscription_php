<?php
    $baseUrl = 'http://wsbd.oo';
    $serverName = 'localhost';
    $dbName = 'wsbd';
    $userName = 'root';
    $password = '';

    $mySqlCon = mysqli_connect($serverName, $userName, $password, $dbName);
   

    if ($mySqlCon->connect_error) {
        die("Connection failed: " . $mySqlCon->connect_error);
    }
?>