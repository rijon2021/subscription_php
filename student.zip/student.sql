-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.33 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table srms.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table srms.admin: ~0 rows (approximately)
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
	(1, 'admin', 'f925916e2754e5e03f75dd58a5733251', '2024-03-10 16:30:57');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;

-- Dumping structure for table srms.payments
CREATE TABLE IF NOT EXISTS `payments` (
  `paymentID` int(11) NOT NULL AUTO_INCREMENT,
  `subscriptionCategoryID` int(11) NOT NULL,
  `StudentId` int(11) NOT NULL,
  `AdmissionNo` int(11) NOT NULL,
  `FullName` varchar(500) NOT NULL,
  `FatherName` varchar(500) NOT NULL,
  `ClassID` int(11) NOT NULL,
  `ClassName` varchar(500) NOT NULL,
  `SessionYear` int(11) NOT NULL,
  `RegistrationNo` varchar(200) DEFAULT NULL,
  `InvoiceID` varchar(500) NOT NULL,
  `paymentDate` timestamp NOT NULL,
  PRIMARY KEY (`paymentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table srms.payments: ~0 rows (approximately)
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;

-- Dumping structure for table srms.students
CREATE TABLE IF NOT EXISTS `students` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `StudentId` int(11) DEFAULT NULL,
  `AdmissionNo` int(11) DEFAULT NULL,
  `FullName` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `ClassID` int(11) DEFAULT NULL,
  `ClassName` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `RollNo` int(11) DEFAULT NULL,
  `RegistrationNo` varchar(500) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table srms.students: ~40 rows (approximately)
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` (`Id`, `StudentId`, `AdmissionNo`, `FullName`, `ClassID`, `ClassName`, `RollNo`, `RegistrationNo`) VALUES
	(1, 166486, 20220744, 'RAZU MIAH', 232, 'HonoursSecondYear', 1111111, '21237250922'),
	(2, 166512, 20220745, 'MD. ARIFUL ISLAM', 232, 'HonoursSecondYear', 1, '21237250930'),
	(3, 166513, 20220746, 'MD. SOHEL RANA', 232, '', 209, '21237250899'),
	(4, 166514, 20220747, 'MD. RIFAT HOSEN', 232, 'HonoursSecondYear', 3, '21237250918'),
	(5, 166515, 20220749, 'MD. RIPON MIA', 232, 'HonoursSecondYear', 4, '21237250925'),
	(6, 166516, 20220750, 'MD. SARWAR HOSSEN SHAKIL', 232, 'HonoursSecondYear', 5, '21237250911'),
	(7, 166517, 20220753, 'MD. MIJAN MIYA', 232, 'HonoursSecondYear', 6, '21237250914'),
	(8, 166518, 20220755, 'MD. JAHIDUL ISLAM', 232, 'HonoursSecondYear', 7, ''),
	(9, 166519, 20220759, 'MD. SOHAG MIA', 232, 'HonoursSecondYear', 8, '21237250920'),
	(10, 166520, 20220767, 'MD. MONIR HOSSEN', 232, 'HonoursSecondYear', 9, ''),
	(11, 166521, 20220748, 'MD. JUWEL MIA', 232, 'HonoursSecondYear', 10, ''),
	(12, 166522, 20220751, 'MD. MURAD', 232, 'HonoursSecondYear', 11, ''),
	(13, 166523, 20220754, 'MD RAFIQUL ISLAM', 232, 'HonoursSecondYear', 12, ''),
	(14, 166524, 20220757, 'MD. RASHED KHAN', 232, 'HonoursSecondYear', 13, ''),
	(15, 166525, 20220768, 'MD. RIAN MIAH', 232, 'HonoursSecondYear', 14, ''),
	(16, 166526, 20220789, 'SUMON KHAN SHUVO', 232, 'HonoursSecondYear', 15, ''),
	(17, 166528, 20221002, 'DIBBO SAHA', 232, 'HonoursSecondYear', 16, ''),
	(18, 166529, 20221033, 'Md. Sohel mondol', 232, 'HonoursSecondYear', 17, ''),
	(19, 166530, 20221051, 'MD. ROBIUL ISLAM', 232, 'HonoursSecondYear', 18, ''),
	(20, 166531, 20221154, 'MD. SAZU MIA', 232, '', 243, ''),
	(21, 166533, 20221163, 'MD. HAFIZ', 232, 'HonoursSecondYear', 20, ''),
	(22, 166534, 20221121, 'MD. IMRAN', 232, 'HonoursSecondYear', 21, ''),
	(23, 166538, 20220752, 'MD. SAMIUL HAQUE', 232, 'HonoursSecondYear', 22, ''),
	(24, 166539, 20220765, 'MD. RANA MIAH', 232, 'HonoursSecondYear', 23, ''),
	(25, 166540, 20220766, 'MD. SUJON', 232, 'HonoursSecondYear', 24, ''),
	(26, 166542, 20221024, 'MOSTAFIZUR', 232, '', 239, ''),
	(27, 166544, 20220930, 'MD. ASHEK MAHMUD LIMON', 232, 'HonoursSecondYear', 26, ''),
	(28, 166546, 20220756, 'MD. ABUSAYED', 232, 'HonoursSecondYear', 27, ''),
	(29, 166767, 20221185, 'MD. KAUSAR MIA', 232, '', 28, ''),
	(30, 166797, 20221628, 'MD. SHAKIL MIA', 232, 'HonoursSecondYear', 29, ''),
	(31, 166798, 20221178, 'MD. AIUB ALI', 232, 'HonoursSecondYear', 30, ''),
	(32, 166799, 20221179, 'MD. RAKIB', 232, 'HonoursSecondYear', 31, ''),
	(33, 166800, 20221175, 'MOSTAKIN', 232, 'HonoursSecondYear', 32, ''),
	(34, 166801, 20221183, 'TARIKUL ISLAM', 232, 'HonoursSecondYear', 33, ''),
	(35, 166802, 20221627, 'MD. RIFATUL ISLAM SHUVON', 232, 'HonoursSecondYear', 34, ''),
	(36, 166803, 20221174, 'ABU TALHA', 232, 'HonoursSecondYear', 35, ''),
	(37, 166819, 20221181, 'SHAHORIAR NAFIS ANTOR', 232, 'HonoursSecondYear', 36, ''),
	(38, 166820, 20221630, 'MD. HAMIDULLAH', 232, 'HonoursSecondYear', 37, ''),
	(39, 166821, 20221631, 'MD. SOHEL RANA', 232, 'HonoursSecondYear', 38, ''),
	(40, 167907, 20221629, 'MD. JOYNAL ABEDIN', 232, '', 2525916, '');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;

-- Dumping structure for table srms.tblclasses
CREATE TABLE IF NOT EXISTS `tblclasses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` varchar(80) DEFAULT NULL,
  `ClassNameNumeric` int(11) DEFAULT NULL,
  `Section` varchar(5) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- Dumping data for table srms.tblclasses: ~8 rows (approximately)
/*!40000 ALTER TABLE `tblclasses` DISABLE KEYS */;
INSERT INTO `tblclasses` (`id`, `ClassName`, `ClassNameNumeric`, `Section`, `CreationDate`, `UpdationDate`) VALUES
	(1, 'First', 1, 'C', '2024-04-25 16:30:57', '2022-01-01 16:30:57'),
	(2, 'Second', 2, 'A', '2024-04-25 16:30:57', '2022-01-01 16:30:57'),
	(4, 'Fourth', 4, 'C', '2024-04-25 16:30:57', '2022-01-01 16:30:57'),
	(5, 'Sixth', 6, 'A', '2024-04-25 16:30:57', '2022-01-01 16:30:57'),
	(6, 'Sixth', 6, 'B', '2024-04-25 16:30:57', '2022-01-01 16:30:57'),
	(7, 'Seventh', 7, 'B', '2024-04-25 16:30:57', '2022-01-01 16:30:57'),
	(8, 'Eight', 8, 'A', '2024-04-25 16:30:57', '2022-01-01 16:30:57'),
	(9, 'Tenth', 10, 'A', '2024-04-25 16:30:57', NULL);
/*!40000 ALTER TABLE `tblclasses` ENABLE KEYS */;

-- Dumping structure for table srms.tblnotice
CREATE TABLE IF NOT EXISTS `tblnotice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `noticeTitle` varchar(255) DEFAULT NULL,
  `noticeDetails` mediumtext,
  `postingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table srms.tblnotice: ~2 rows (approximately)
/*!40000 ALTER TABLE `tblnotice` DISABLE KEYS */;
INSERT INTO `tblnotice` (`id`, `noticeTitle`, `noticeDetails`, `postingDate`) VALUES
	(2, 'Notice regarding result Delearation', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Adipiscing elit ut aliquam purus. Vel risus commodo viverra maecenas. Et netus et malesuada fames ac turpis egestas sed. Cursus eget nunc scelerisque viverra mauris in aliquam sem fringilla. Ornare arcu odio ut sem nulla pharetra diam. Vel pharetra vel turpis nunc eget lorem dolor sed. Velit ut tortor pretium viverra suspendisse. In ornare quam viverra orci sagittis eu. Viverra tellus in hac habitasse. Donec massa sapien faucibus et molestie. Libero justo laoreet sit amet cursus sit amet dictum. Dignissim diam quis enim lobortis scelerisque fermentum dui.\r\n\r\nEget nulla facilisi etiam dignissim. Quisque non tellus orci ac. Amet cursus sit amet dictum sit amet justo donec. Interdum velit euismod in pellentesque massa. Condimentum lacinia quis vel eros donec ac odio. Magna eget est lorem ipsum dolor. Bibendum at varius vel pharetra vel turpis nunc eget lorem. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit amet. Maecenas accumsan lacus vel facilisis volutpat est velit egestas dui. Massa tincidunt dui ut ornare lectus sit amet est placerat. Nisi quis eleifend quam adipiscing vitae.', '2024-05-01 20:34:58'),
	(3, 'Test Notice', 'This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  This is for testing purposes only.  ', '2024-05-02 20:48:32');
/*!40000 ALTER TABLE `tblnotice` ENABLE KEYS */;

-- Dumping structure for table srms.tblresult
CREATE TABLE IF NOT EXISTS `tblresult` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `StudentId` int(11) DEFAULT NULL,
  `ClassId` int(11) DEFAULT NULL,
  `SubjectId` int(11) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

-- Dumping data for table srms.tblresult: ~20 rows (approximately)
/*!40000 ALTER TABLE `tblresult` DISABLE KEYS */;
INSERT INTO `tblresult` (`id`, `StudentId`, `ClassId`, `SubjectId`, `marks`, `PostingDate`, `UpdationDate`) VALUES
	(2, 1, 1, 2, 100, '2024-05-10 16:30:57', NULL),
	(3, 1, 1, 1, 80, '2024-05-10 16:30:57', NULL),
	(4, 1, 1, 5, 78, '2024-05-10 16:30:57', NULL),
	(5, 1, 1, 4, 60, '2024-05-10 16:30:57', NULL),
	(6, 2, 4, 2, 90, '2024-05-10 16:30:57', NULL),
	(7, 2, 4, 1, 75, '2024-05-10 16:30:57', NULL),
	(8, 2, 4, 5, 56, '2024-05-10 16:30:57', NULL),
	(9, 2, 4, 4, 80, '2024-05-10 16:30:57', NULL),
	(10, 4, 7, 2, 54, '2024-05-10 16:30:57', NULL),
	(11, 4, 7, 1, 85, '2024-05-10 16:30:57', NULL),
	(12, 4, 7, 5, 55, '2024-05-10 16:30:57', NULL),
	(13, 4, 7, 7, 65, '2024-05-10 16:30:57', NULL),
	(14, 5, 8, 2, 75, '2024-05-10 16:30:57', NULL),
	(15, 5, 8, 1, 56, '2024-05-10 16:30:57', NULL),
	(16, 5, 8, 5, 52, '2024-05-10 16:30:57', NULL),
	(17, 5, 8, 4, 80, '2024-05-10 16:30:57', NULL),
	(18, 6, 9, 8, 80, '2024-05-20 21:20:18', NULL),
	(19, 6, 9, 8, 70, '2024-05-20 21:20:18', NULL),
	(20, 6, 9, 2, 90, '2024-05-20 21:20:18', NULL),
	(21, 6, 9, 1, 60, '2024-05-20 21:20:18', NULL);
/*!40000 ALTER TABLE `tblresult` ENABLE KEYS */;

-- Dumping structure for table srms.tblstudents
CREATE TABLE IF NOT EXISTS `tblstudents` (
  `StudentId` int(11) NOT NULL AUTO_INCREMENT,
  `StudentName` varchar(100) DEFAULT NULL,
  `RollId` varchar(100) DEFAULT NULL,
  `StudentEmail` varchar(100) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `DOB` varchar(100) DEFAULT NULL,
  `ClassId` int(11) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  PRIMARY KEY (`StudentId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table srms.tblstudents: ~6 rows (approximately)
/*!40000 ALTER TABLE `tblstudents` DISABLE KEYS */;
INSERT INTO `tblstudents` (`StudentId`, `StudentName`, `RollId`, `StudentEmail`, `Gender`, `DOB`, `ClassId`, `RegDate`, `UpdationDate`, `Status`) VALUES
	(1, 'Sarita', '46456', 'info@phpgurukul.com', 'Female', '1995-03-03', 1, '2024-04-20 16:30:57', NULL, 1),
	(2, 'Anuj kumar', '10861', 'anuj@gmail.co', 'Male', '1995-02-02', 4, '2024-04-24 16:30:57', NULL, 0),
	(3, 'amit kumar', '2626', 'amit@gmail.com', 'Male', '2014-08-06', 6, '2024-04-22 16:30:57', NULL, 1),
	(4, 'rahul kumar', '990', 'rahul01@gmail.com', 'Male', '2001-02-03', 7, '2024-04-24 16:30:57', NULL, 1),
	(5, 'sanjeev singh', '122', 'sanjeev01@gmail.com', 'Male', '2002-02-03', 8, '2024-04-25 16:30:57', NULL, 1),
	(6, 'Shiv Gupta', '12345', 'shiv34534@gmail.com', 'Male', '2007-01-12', 9, '2024-05-01 21:19:40', NULL, 1);
/*!40000 ALTER TABLE `tblstudents` ENABLE KEYS */;

-- Dumping structure for table srms.tblsubjectcombination
CREATE TABLE IF NOT EXISTS `tblsubjectcombination` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ClassId` int(11) DEFAULT NULL,
  `SubjectId` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `Updationdate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

-- Dumping data for table srms.tblsubjectcombination: ~26 rows (approximately)
/*!40000 ALTER TABLE `tblsubjectcombination` DISABLE KEYS */;
INSERT INTO `tblsubjectcombination` (`id`, `ClassId`, `SubjectId`, `status`, `CreationDate`, `Updationdate`) VALUES
	(3, 2, 5, 0, '2024-05-01 16:30:57', '2024-06-07 11:25:49'),
	(4, 1, 2, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(5, 1, 4, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(6, 1, 5, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(8, 4, 4, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(10, 4, 1, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(12, 4, 2, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(13, 4, 5, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(14, 6, 1, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(15, 6, 2, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(16, 6, 4, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(17, 6, 6, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(18, 7, 1, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(19, 7, 7, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(20, 7, 2, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(21, 7, 6, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(22, 7, 5, 0, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(23, 8, 1, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(24, 8, 2, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(25, 8, 4, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(26, 8, 6, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(27, 8, 5, 0, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(28, 9, 1, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(29, 9, 2, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(30, 9, 8, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00'),
	(31, 9, 8, 1, '2024-05-01 16:30:57', '2024-06-07 10:28:00');
/*!40000 ALTER TABLE `tblsubjectcombination` ENABLE KEYS */;

-- Dumping structure for table srms.tblsubjects
CREATE TABLE IF NOT EXISTS `tblsubjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `SubjectName` varchar(100) NOT NULL,
  `SubjectCode` varchar(100) DEFAULT NULL,
  `Creationdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table srms.tblsubjects: ~7 rows (approximately)
/*!40000 ALTER TABLE `tblsubjects` DISABLE KEYS */;
INSERT INTO `tblsubjects` (`id`, `SubjectName`, `SubjectCode`, `Creationdate`, `UpdationDate`) VALUES
	(1, 'Maths', 'MTH01', '2024-04-25 16:30:57', NULL),
	(2, 'English', 'ENG11', '2024-04-25 16:30:57', NULL),
	(4, 'Science', 'SC1', '2024-04-25 16:30:57', NULL),
	(5, 'Music', 'MS', '2024-04-25 16:30:57', NULL),
	(6, 'Social Studies', 'SS08', '2024-04-25 16:30:57', NULL),
	(7, 'Physics', 'PH03', '2024-04-25 16:30:57', NULL),
	(8, 'Chemistry', 'CH65', '2024-04-25 16:30:57', NULL);
/*!40000 ALTER TABLE `tblsubjects` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
