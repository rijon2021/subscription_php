<?php

$servername = "localhost";
$username = "websuppo_rijon"; // Put the MySQL Username
$password = "rijon@2023#"; // Put the MySQL Password
$database = "websuppo_wsbd"; // Put the Database Name

// Create connection for integration
$conn_integration = mysqli_connect($servername, $username, $password, $database);

// Check connection for integration
if (!$conn_integration) {
    die("Connection failed: " . mysqli_connect_error());
}

